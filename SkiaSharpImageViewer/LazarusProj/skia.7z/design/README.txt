Skia.LCL.Design.res was created with:

lazarus/tools/lazres Skia.LCL.Design.res icons/*
