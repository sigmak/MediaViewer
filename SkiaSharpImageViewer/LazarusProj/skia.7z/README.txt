see https://wiki.freepascal.org/Skia
