Copy the files from here to ZenGL folder in the "demos\Lazarus" subfolder.

Open BGRABitmapPack4NoGUI_OpenGL package and then open one of the demos.

Note that one demo requires "arial.ttf" to be copied next to the executable.